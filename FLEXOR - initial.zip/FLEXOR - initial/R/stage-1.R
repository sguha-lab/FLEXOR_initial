
#' @export
balancing.weights <- function(S, Z, X, method, naturalGroupProp, num.random=40, gammaMin=1e-3, gammaMax = (1-1e-3), seed=NULL)
{

  if (!("fn.FLEXOR" %in% objects())){
    source("R/preamble.R", echo=FALSE)
  }

  flexorFlag = method %in% c("FLEXOR", "flexor")

  fn.userInputChecks_1(method, flexorFlag, gammaMin, gammaMax, num.random, naturalGroupProp)

  if (!is.null(seed)){
    if (!is.natural(seed))
      stop("seed must be a natural number.")

    set.seed(seed)
  }

  data = fn.createListData(S, Z, X)

  text = fn.userInputChecks_2(data)

  c(return.parm, percentESS) %<-% suppress_conditions(fn.Weights(data, method, flexorFlag, num.random, naturalGroupProp, gammaMin, gammaMax))

  output1 = NULL
  output1$wt.v = return.parm$wt.v
  output1$percentESS =   percentESS

  return(output1)
}
