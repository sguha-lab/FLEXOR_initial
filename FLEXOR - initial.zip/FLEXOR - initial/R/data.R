#' Demo Dataset
#'
#' A dataset for demonstrating purposes.
#'
#' @format An `.Rdata` object containing <details of the data>.
#' @examples
#' data(demo)
"demo"
