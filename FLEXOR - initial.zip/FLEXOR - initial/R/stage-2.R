
#' @export
causal.estimate <- function(S, Z, X, Y, B=100, method, naturalGroupProp=NULL, num.random=40, gammaMin=1e-3, gammaMax = (1-1e-3), seed=NULL)
{

  if (!("fn.FLEXOR" %in% objects())){
    source("R/preamble.R", echo=FALSE)
  }

  Y = matrix(Y, nrow=nrow(Y))

  output1 = balancing.weights(S, Z, X, method, naturalGroupProp, num.random, gammaMin, gammaMax, seed)

  data = fn.createListData(S, Z, X, Y)

  fn.userInputChecks_3(data)

  flexorFlag = method %in% c("FLEXOR", "flexor")

  if (flexorFlag)
    estDenom = naturalGroupProp

  if (!flexorFlag)
    estDenom = rep(1, data$K)/data$K

  c(moments.ar, otherFeatures.v) %<-% fn.Stage2(local_data=data, local_wt.v=output1$wt.v, estDenom)

  if (B>0){

      c(collatedMoments.ar, collatedOtherFeatures.mt) %<-% bootStrap(data, moments.ar, otherFeatures.v, B, method=method, method_wt.v=output1$wt.v, naturalGroupProp, num.random.b = num.random, gammaMin, gammaMax, seed, estDenom)

  }

  output2 = NULL

  output2$percentESS = output1$percentESS
  output2$moments.ar = moments.ar
  output2$otherFeatures.v = otherFeatures.v
  output2$collatedMoments.ar = collatedMoments.ar
  output2$collatedOtherFeatures.mt = collatedOtherFeatures.mt

  output2
}

