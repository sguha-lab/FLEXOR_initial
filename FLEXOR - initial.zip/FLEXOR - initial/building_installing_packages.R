
## unload a loaded package without restarting R
#    detach("package:FLEXOR", unload=TRUE)

devtools::build()

install.packages("../FLEXOR_0.0.0.9000.tar.gz")

library(FLEXOR)
